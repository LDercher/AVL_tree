#ifndef UTIL_HPP
#define UTIL_HPP

#include <cstdio>
#include <iostream>

#define IMPLEMENT_ME() printf("unimplmemented %s\n", __PRETTY_FUNCTION__)

/*void printBook(Book *b) {
  std::cout << "Book id: " << b->getId() << " name: " << b->getName()
            << " publisher: " << b->getPublisher()
            << " current count in stock: " << b->getCurrentCount()
            << " of total count in inventory: " << b->getTotalCount()
            << std::endl;
}*/

#endif // UTIL_HPP defined
